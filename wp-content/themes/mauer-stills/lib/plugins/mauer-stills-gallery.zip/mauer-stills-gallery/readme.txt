
This plugin was created using the Create-Guten-Block library by Ahmad Awais.
https://github.com/ahmadawais/create-guten-block

If you would like to alter the block (contained in the 'src' folder), please run 'npm install', and then 'npm start'.